from switss.utils import treap_testcases

def test_utils_treap():
    treap_testcases()
